▲ DATUMBUILT CLASH TOOLS 1.2.1

Requirements: Autodesk Navisworks Manage 2027 and Windows 10 or later.

Install:
1. Close Navisworks Manage.
2. Extract this ZIP completely.
3. Double-click Install.cmd.
4. Open Navisworks Manage 2027.

The plug-in adds ▲ DATUMBUILT > Toggle Clash Hide Other and starts the local-only Stream Deck bridge on 127.0.0.1:42727.

Uninstall: close Navisworks and double-click Uninstall.cmd.
