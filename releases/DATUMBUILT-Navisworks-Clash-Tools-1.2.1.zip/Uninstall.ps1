$ErrorActionPreference = 'Stop'
$target = Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins\VC.Navisworks2027Starter.bundle'
if (Get-Process -Name 'Roamer' -ErrorAction SilentlyContinue) { throw 'Close Navisworks Manage before uninstalling.' }
if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force; Write-Host "Removed $target" } else { Write-Host '▲ DATUMBUILT Clash Tools is not installed for this user.' }
