$ErrorActionPreference = 'Stop'
if (Get-Process -Name 'Roamer' -ErrorAction SilentlyContinue) { throw 'Close Navisworks Manage before installing.' }
$source = Join-Path $PSScriptRoot 'VC.Navisworks2027Starter.bundle'
$target = Join-Path $env:APPDATA 'Autodesk\ApplicationPlugins\VC.Navisworks2027Starter.bundle'
if (-not (Test-Path -LiteralPath $source)) { throw "The plug-in bundle was not found at '$source'." }
New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
Copy-Item -LiteralPath $source -Destination $target -Recurse -Force
Write-Host "Installed ▲ DATUMBUILT Clash Tools 1.2.1 to $target"
Write-Host 'Start Navisworks Manage 2027 to finish loading the plug-in.'
