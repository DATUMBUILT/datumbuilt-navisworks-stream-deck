▲ DATUMBUILT Navisworks Tools 1.3.0

Requirements: Autodesk Navisworks Manage 2027 on Windows.

1. Close Navisworks Manage 2027.
2. Double-click Install.cmd.
3. Restart Navisworks.

The companion DATUMBUILT Stream Deck plug-in uses a loopback-only bridge on 127.0.0.1:42727.
Run Uninstall.cmd to remove this add-in.